//
//  Navi.swift
//  VitorMagalhaes_RM84808_Modelo3
//
//  Created by Usuário Convidado on 17/10/23.
//

import Foundation

struct UmaNavi:Decodable{
    var name:String
    var model:String
    var manufacturer: String
}
